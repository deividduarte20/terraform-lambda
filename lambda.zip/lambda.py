import boto3


def lambda_handler(event, context):
    # Obtém informações sobre o evento do S3
    s3_event = event['Records'][0]['s3']
    bucket_name = s3_event['bucket']['name']
    object_key = s3_event['object']['key']

    # Define o ID da distribuição do CloudFront
    distribution_id = 'E1TRR3ZBITPXAU'

    # Cria uma instância do cliente do CloudFront
    cloudfront_client = boto3.client('cloudfront')

    # Invalida o cache para o arquivo especificado
    cloudfront_client.create_invalidation(
        DistributionId=distribution_id,
        InvalidationBatch={
            'Paths': {
                'Quantity': 1,
                'Items': [
                    '/' + object_key
                ]
            },
            'CallerReference': str(hash(object_key))
        }
    )